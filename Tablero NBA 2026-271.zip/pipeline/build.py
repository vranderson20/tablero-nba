"""Genera nba.html a partir de template.html + datos, y actualiza data/history.json.
Uso: python3 models.py && python3 build.py [--asof "5 nov 2026"]"""
import json, glob, sys, datetime as dt
import pandas as pd

NAMES = {"ATL":("Hawks","E"),"BOS":("Celtics","E"),"BKN":("Nets","E"),"CHA":("Hornets","E"),"CHI":("Bulls","E"),"CLE":("Cavaliers","E"),
 "DET":("Pistons","E"),"IND":("Pacers","E"),"MIA":("Heat","E"),"MIL":("Bucks","E"),"NYK":("Knicks","E"),"ORL":("Magic","E"),"PHI":("76ers","E"),
 "TOR":("Raptors","E"),"WAS":("Wizards","E"),"DAL":("Mavericks","W"),"DEN":("Nuggets","W"),"GSW":("Warriors","W"),"HOU":("Rockets","W"),
 "LAC":("Clippers","W"),"LAL":("Lakers","W"),"MEM":("Grizzlies","W"),"MIN":("Timberwolves","W"),"NOP":("Pelicans","W"),"OKC":("Thunder","W"),
 "PHX":("Suns","W"),"POR":("Trail Blazers","W"),"SAC":("Kings","W"),"SAS":("Spurs","W"),"UTA":("Jazz","W")}
TO_PAGE = {"PHX":"PHO","CHA":"CHO","BKN":"BRK"}
pg = lambda t: TO_PAGE.get(t, t)
DIAS = ["lun","mar","mié","jue","vie","sáb","dom"]; MESES = ["ene","feb","mar","abr","may","jun","jul","ago","sep","oct","nov","dic"]
def dlabel(d): d = pd.Timestamp(d); return f"{DIAS[d.weekday()]} {d.day} {MESES[d.month-1]}"

M = json.load(open("model_out.json"))
G = pd.concat([pd.read_csv(f, header=None, names=["date","a","ap","h","hp"]) for f in sorted(glob.glob("data/games/*.csv"))]).drop_duplicates()
G["date"] = pd.to_datetime(G.date)
G["season"] = G.date.dt.year.where(G.date.dt.month < 7, G.date.dt.year + 1)
CUR = int(G.season.max()); C = G[G.season == CUR]
SCH = pd.read_csv("data/schedule.csv")
ODDS = json.load(open("data/odds.json")) if glob.glob("data/odds.json") else {}
try: HIST = json.load(open("data/history.json"))
except FileNotFoundError: HIST = []
asof = sys.argv[sys.argv.index("--asof") + 1] if "--asof" in sys.argv else dlabel(dt.date.today()).split(" ", 1)[1] + f" {dt.date.today().year}"

# ---- lesiones (ESPN) ----
import unicodedata, csv
FULL = {"Atlanta Hawks":"ATL","Boston Celtics":"BOS","Brooklyn Nets":"BRK","Charlotte Hornets":"CHO","Chicago Bulls":"CHI","Cleveland Cavaliers":"CLE",
 "Dallas Mavericks":"DAL","Denver Nuggets":"DEN","Detroit Pistons":"DET","Golden State Warriors":"GSW","Houston Rockets":"HOU","Indiana Pacers":"IND",
 "LA Clippers":"LAC","Los Angeles Clippers":"LAC","Los Angeles Lakers":"LAL","Memphis Grizzlies":"MEM","Miami Heat":"MIA","Milwaukee Bucks":"MIL",
 "Minnesota Timberwolves":"MIN","New Orleans Pelicans":"NOP","New York Knicks":"NYK","Oklahoma City Thunder":"OKC","Orlando Magic":"ORL",
 "Philadelphia 76ers":"PHI","Phoenix Suns":"PHO","Portland Trail Blazers":"POR","Sacramento Kings":"SAC","San Antonio Spurs":"SAS",
 "Toronto Raptors":"TOR","Utah Jazz":"UTA","Washington Wizards":"WAS"}
import re as _re
norm = lambda n: _re.sub(r"\s+(jr|sr|ii|iii|iv)$", "", unicodedata.normalize("NFD", n).encode("ascii", "ignore").decode().lower().replace(".", "").replace("'", "").strip())
INJ = {}
if glob.glob("data/injuries.csv"):
    for r in csv.DictReader(open("data/injuries.csv", encoding="utf-8")):
        try:
            rd = pd.Timestamp(f'{r["return_date"]} {CUR - 1}')
            if rd.month < 7: rd = rd.replace(year=CUR)
            rd = str(rd.date())
        except Exception: rd = None
        INJ[norm(r["player"])] = dict(n=r["player"], st=r["status"], tm=FULL.get(r["team"], ""), s="out" if r["status"].lower().startswith("out") else "q", r=rd, c=r["comment"][:90])


# ---- ajuste de los pronósticos por bajas (lesiones) ----
from scipy.stats import norm as _n
PL = pd.read_csv("data/players.csv")
# ESPN: la fecha de regreso es el primer partido en que se espera que vuelva.
# Fuera (peso 1): "Out" y el partido es antes de esa fecha. Duda (peso 0.5): "Day-To-Day" hasta esa fecha, u "Out" justo en la fecha de regreso.
def out_w(name, tm, date):
    e = INJ.get(norm(name))
    if not e or (e["tm"] and e["tm"] != tm): return 0.0
    if e["s"] == "out" and (not e["r"] or e["r"] > date): return 1.0
    if not e["r"] or e["r"] >= date: return 0.5
    return 0.0
# ---- impacto de cada jugador (BPM de Basketball-Reference; si falta, estimado con sus estadísticas por 36 min) ----
import numpy as np
from sklearn.linear_model import Ridge
BP = pd.read_csv("data/bpm.csv") if glob.glob("data/bpm.csv") else pd.DataFrame(columns=["Player","MP","BPM"])
BPM = {norm(r.Player): (float(r.BPM), float(r.MP)) for r in BP.itertuples()}
def _x(r): m = max(r.MP, 1); return [r.PTS/m*36, r.TRB/m*36, r.AST/m*36, r.STL/m*36, r.BLK/m*36, r.TOV/m*36, r._7/m*36, r._6]
_tr = [(r, BPM[norm(r.Player)]) for r in PL.itertuples(index=False) if norm(r.Player) in BPM and r.MP > 8]
if len(_tr) > 40:
    _rg = Ridge(alpha=1.0).fit([_x(r) for r, _ in _tr], [b for _, (b, _m) in _tr], sample_weight=[m_ for _, (_b, m_) in _tr])
    box_est = lambda r: float(_rg.predict([_x(r)])[0])
else:
    box_est = lambda r: -2.0
REPL = -2.0
def rating(r):
    est = box_est(r); mt = r.G * r.MP
    if norm(r.Player) in BPM: b, m_ = BPM[norm(r.Player)]; return (m_ * b + 300 * est) / (m_ + 300)
    return (mt * est + 100 * REPL) / (mt + 100)
def impact(r):   # promedio de dos estimaciones: BPM (eficiencia) y producción bruta (volumen)
    bpm_i = max(0.0, 0.8 * (rating(r) - REPL) * r.MP / 48)
    vol_i = 0.15 * max(0.0, r.PTS + 0.4 * r.TRB + 0.7 * r.AST + r.STL + 0.7 * r.BLK - r.TOV)
    return 0.5 * bpm_i + 0.5 * vol_i
def team_loss(t, date):
    tp = PL[PL.Team == pg(t)]; tg = max(1, int(tp.G.max())) if len(tp) else 1; loss = 0.0; outs = []
    for r in tp.itertuples(index=False):
        w_ = out_w(r.Player, pg(t), date)
        if w_:
            l = w_ * impact(r) * min(1.0, 0.5 + r.G / tg / 2); loss += l
            if l >= 0.3: outs.append([r.Player, round(l, 1)])
    return round(loss, 2), sorted(outs, key=lambda x: -x[1])
SD = M.get("resid_sd", 12.9)
W_MKT = 0.7   # peso del mercado: en los partidos en vivo las cuotas acertaron más que los modelos solos
for p in M["preds"]:
    lh, oh = team_loss(p["h"], p["date"]); la, oa = team_loss(p["a"], p["date"])
    d = la - lh
    p["inj"] = dict(h=lh, a=la, outs_h=oh, outs_a=oa, shift=round(d, 2))
    if abs(d) > 0:
        for k_, v in list(p["probs"].items()):
            v = min(max(v, 1e-4), 1 - 1e-4); p["probs"][k_] = round(float(_n.cdf(_n.ppf(v) + d / SD)), 4)
        p["margin"] = round(p["margin"] + d, 2)
    p["total"] = round(p["total"] - 0.6 * (lh + la), 1)

# ---- clasificación desde los resultados ----
TEAMS = {}
for t, (n, c) in NAMES.items():
    hm, aw = C[C.h == t], C[C.a == t]
    w = int((hm.hp > hm.ap).sum() + (aw.ap > aw.hp).sum()); g = len(hm) + len(aw)
    pf = (hm.hp.sum() + aw.ap.sum()) / g if g else 0; pa = (hm.ap.sum() + aw.hp.sum()) / g if g else 0
    TEAMS[pg(t)] = [n, c, w, g - w, round(float(pf), 1), round(float(pa), 1)]

# ---- mercado ----
impl = lambda ml: -ml / (-ml + 100) if ml < 0 else 100 / (ml + 100)
def fair_home(k):
    o = ODDS.get(k, {}).get("cur", {})
    if o.get("a") is None or o.get("h") is None: return None
    ia, ih = impl(o["a"]), impl(o["h"]); return ih / (ia + ih)

# ---- histórico: calificar resultados y registrar pronósticos ----
res = {f"{r.date.date()}-{r.a}-{r.h}": (int(r.ap), int(r.hp)) for r in G.itertuples()}
byid = {e["id"]: e for e in HIST}
for p in M["preds"]:
    gid = f'{p["date"]}-{p["a"]}-{p["h"]}'
    if gid in res: continue                      # ya se jugó: no se reescribe el pronóstico
    if p["date"] > str(dt.date.today() + dt.timedelta(days=2)): continue   # solo se registran los partidos de los próximos días
    pm = fair_home(f'{p["a"]}-{p["h"]}'); pe = p["probs"]["ensamble"]
    byid[gid] = dict(id=gid, date=p["date"], a=p["a"], h=p["h"], src="en vivo", pe=round(pe, 4),
                     pm=round(pm, 4) if pm is not None else None, p=round(W_MKT * pm + (1 - W_MKT) * pe if pm is not None else pe, 4),
                     php=round((p["total"] + p["margin"]) / 2, 1), pap=round((p["total"] - p["margin"]) / 2, 1),
                     logged=str(dt.date.today()), ap=None, hp=None)
for b in M.get("backtest", []):
    gid = f'{b["date"]}-{b["a"]}-{b["h"]}'
    if gid not in byid or byid[gid]["src"] == "validación":
        byid[gid] = dict(id=gid, date=b["date"], a=b["a"], h=b["h"], src="validación", pe=b["p"], pm=None, p=b["p"],
                         php=None, pap=None, logged=None, ap=b["ap"], hp=b["hp"])
for e in byid.values():
    if e["id"] in res: e["ap"], e["hp"] = res[e["id"]]
HIST = sorted(byid.values(), key=lambda e: (e["date"], e["id"]))
json.dump(HIST, open("data/history.json", "w"), ensure_ascii=False, indent=0)

# ---- página ----
P = pd.read_csv("data/players.csv")
csv = "\n".join(",".join(str(v) for v in r) for r in P.itertuples(index=False))
games = [[dlabel(r.date), r.time, pg(r.away), pg(r.home), str(r.date)] for r in SCH.itertuples()]
model = dict(stack=M.get("stack"), metrics=M["metrics"], n_test=M["n_test"], n_all=M["n_all"], imp_rf=M["imp_rf"], imp_gb=M["imp_gb"], coef_lin=M["coef_lin"],
             elo=M["elo"], ewma=M["ewma"], series=M["series"], resid_sd=M["resid_sd"], tot_sd=M["tot_sd"],
             preds={p["a"] + "-" + p["h"] + "|" + p["date"]: {**{k: p[k] for k in ["probs","margin","total","lam_h","lam_a","elo_h","elo_a"]},
                    "rest_h": p["feats"]["h_rest"], "rest_a": p["feats"]["a_rest"], "inj": p.get("inj"), "date": p["date"]} for p in M["preds"]})
# impacto de cada jugador (para que la página recalcule las bajas con el reporte de lesiones en vivo de ESPN)
_imp = {}
for _t in PL.Team.unique():
    _tp = PL[PL.Team == _t]; _tg = max(1, int(_tp.G.max()))
    for r in _tp.itertuples(index=False):
        v = impact(r) * min(1.0, 0.5 + r.G / _tg / 2)
        if v >= 0.05: _imp[norm(r.Player) + "|" + _t] = round(v, 2)
model["impact"] = _imp
model["elo_cfg"] = dict(K=28, HCA=40, w_elo=(M.get("stack") or {}).get("w_final", {}).get("elo", 0.85) if (M.get("stack") or {}).get("method") == "ponderado" else 1 / 8)
market = {k: {"open": v.get("open"), "cur": v["cur"], "src": v.get("src", "Casas")} for k, v in ODDS.items() if any(q.startswith(k + "|") for q in model["preds"])}
J = lambda o: json.dumps(o, ensure_ascii=False, separators=(",", ":"))
h = open("template.html").read()
for k, v in {"__TEAMS__": J(TEAMS), "__CSV__": J(csv), "__GAMES__": J(games), "__MODEL__": J(model), "__HISTORY__": J(HIST),
             "__MARKET__": J(market), "__FUTBOL__": J(json.load(open("futbol_out.json")) if glob.glob("futbol_out.json") else {}), "__INJ__": J(INJ), "__ASOF__": asof, "__NGAMES__": f'{M["n_games"]:,}'.replace(",", "."),
             "__NTEST__": str(M["n_test"]), "__NPLAYERS__": str(len(P)), "__SEASON__": f"{CUR-1}-{str(CUR)[2:]}"}.items():
    h = h.replace(k, v)
assert "__" not in h.replace("__proto__", ""), "placeholder sin reemplazar"
open("nba.html", "w").write(h)
live = [e for e in HIST if e["src"] == "en vivo"]
print(f"OK · {len(games)} partidos próximos · histórico {len(HIST)} ({len(live)} en vivo, {sum(e['hp'] is not None for e in live)} calificados)")
