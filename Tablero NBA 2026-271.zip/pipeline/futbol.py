"""Pronósticos de fútbol con Poisson (ataque/defensa por equipo) + corrección Dixon-Coles.
Lee data/futbol/<liga>.csv (tabla) y <liga>.fixtures.csv; escribe futbol_out.json."""
import csv, json, math, os, re, unicodedata, datetime as dt
LEAGUES = [("col.1","Liga BetPlay","Clausura 2026",1.16,0.86),("eng.1","Premier League","2026-27",1.12,0.89),
 ("esp.1","LaLiga","2026-27",1.12,0.89),("ita.1","Serie A","2026-27",1.11,0.90),("ger.1","Bundesliga","2026-27",1.11,0.90),
 ("fra.1","Ligue 1","2026-27",1.12,0.89),("por.1","Primeira Liga","2026-27",1.12,0.89),("ned.1","Eredivisie","2026-27",1.12,0.89),("eng.2","Championship","2026-27",1.11,0.90),("esp.2","LaLiga 2","2026-27",1.13,0.88),("usa.1","MLS","2026 · tabla general",1.15,0.87),("uefa.champions","Champions League","2026-27 · fase de liga",1.10,0.91),
 ("uefa.europa","Europa League","2026-27 · fase de liga",1.10,0.91),("uefa.europa.conf","Conference League","2026-27 · fase de liga",1.10,0.91)]
SHR, RHO, MAXG = 4, -0.10, 10
pois = lambda k, l: math.exp(-l) * l ** k / math.factorial(k)
def tau(i, j, lh, la):
    if i == 0 and j == 0: return 1 - lh * la * RHO
    if i == 0 and j == 1: return 1 + lh * RHO
    if i == 1 and j == 0: return 1 + la * RHO
    if i == 1 and j == 1: return 1 - RHO
    return 1.0
def predict(lh, la):
    g = [[pois(i, lh) * pois(j, la) * tau(i, j, lh, la) for j in range(MAXG + 1)] for i in range(MAXG + 1)]
    s = sum(map(sum, g)); g = [[v / s for v in r] for r in g]
    p1 = sum(g[i][j] for i in range(MAXG + 1) for j in range(MAXG + 1) if i > j)
    px = sum(g[i][i] for i in range(MAXG + 1)); p2 = 1 - p1 - px
    o25 = sum(g[i][j] for i in range(MAXG + 1) for j in range(MAXG + 1) if i + j > 2)
    o15 = sum(g[i][j] for i in range(MAXG + 1) for j in range(MAXG + 1) if i + j > 1)
    o35 = sum(g[i][j] for i in range(MAXG + 1) for j in range(MAXG + 1) if i + j > 3)
    btts = sum(g[i][j] for i in range(1, MAXG + 1) for j in range(1, MAXG + 1))
    top = sorted(((g[i][j], f"{i}-{j}") for i in range(6) for j in range(6)), reverse=True)[:3]
    grid = [[round(g[i][j], 5) for j in range(8)] for i in range(8)]
    return dict(grid=grid, p1=round(p1, 4), px=round(px, 4), p2=round(p2, 4), o15=round(o15, 4), o25=round(o25, 4), o35=round(o35, 4), btts=round(btts, 4),
                scores=[[s_, round(p, 3)] for p, s_ in top], lh=round(lh, 2), la=round(la, 2))
STOP = {"fc","cf","sc","ac","as","afc","cd","rc","ud","ca","us","ss","ssc","acf","cfc","bv","tsg","fsv","club","de","sv","rcd","og","ogc","osc","es","sco","calcio","1913","1909","1907","1899","1901","05","07","09","29","04","balompie","futbol","milano","alsace","stade","real","sporting","atletico","borussia","1."}
ALIAS = {"lafc":"los","ajax":"ajax","famalicao":"famalicao","guimaraes":"vitoria","amadora":"estrela","lisboa":"benfica","cambuur":"cambuur","nec":"nijmegen","lyonnais":"lyon","hamburger":"hamburg","brestois":"brest","munchen":"munich","koln":"cologne","internazionale":"internazionale","inter":"internazionale","psg":"paris"}
def toks(n):
    n = unicodedata.normalize("NFD", n).encode("ascii", "ignore").decode().lower()
    t = [ALIAS.get(x, x) for x in re.findall(r"[a-z0-9]+", n)]
    k = [x for x in t if x not in STOP]
    return set(k or t)
def sim(a, b):
    A, B = toks(a), toks(b); return len(A & B) / max(1, min(len(A), len(B)))
today = os.environ.get("HOY") or str(dt.date.today())
out = []
for lid, name, season, hf, af in LEAGUES:
    tbl = []
    for r in csv.reader(open(f"data/futbol/{lid}.csv", encoding="utf-8")):
        if len(r) < 10 or not r[0].strip().isdigit(): continue
        pos, team, gp, w, d, l, gf, ga, gd, pts = r[:10]
        tbl.append(dict(pos=int(pos), team=team, gp=int(gp), w=int(w), d=int(d), l=int(l), gf=int(gf), ga=int(ga), pts=int(pts)))
    tg = sum(t["gp"] for t in tbl) or 1; mu = sum(t["gf"] for t in tbl) / tg
    S = {}
    for t in tbl:
        k = t["gp"] / (t["gp"] + SHR) if t["gp"] else 0
        att = (t["gf"] / t["gp"] / mu) if t["gp"] else 1; dfn = (t["ga"] / t["gp"] / mu) if t["gp"] else 1
        S[t["team"]] = (1 + (att - 1) * k, 1 + (dfn - 1) * k)
    CF = {}
    cp = f"data/futbol/{lid}.corners.csv"
    if os.path.exists(cp):
        for r in csv.reader(open(cp, encoding="utf-8")):
            if len(r) >= 2 and r[0] in S:
                try: CF[r[0]] = float(r[1])
                except ValueError: pass
    SH = {}
    sp_ = f"data/futbol/{lid}.shots.csv"
    if os.path.exists(sp_):
        for r in csv.reader(open(sp_, encoding="utf-8")):
            if len(r) >= 3 and r[0] in S:
                try: SH[r[0]] = (float(r[1]), float(r[2]))
                except ValueError: pass
    MK = []
    mp_ = f"data/futbol/{lid}.market.csv"
    if os.path.exists(mp_):
        for r in csv.reader(open(mp_, encoding="utf-8")):
            if len(r) >= 6:
                try: MK.append(dict(date=r[0], h=r[1], a=r[2], p1=float(r[3]), px=float(r[4]), p2=float(r[5]),
                                    line=float(r[6]) if len(r) > 6 and r[6] else None, ov=float(r[7]) if len(r) > 7 and r[7] else None, un=float(r[8]) if len(r) > 8 and r[8] else None))
                except ValueError: pass
    fx = []
    fp = f"data/futbol/{lid}.fixtures.csv"
    if os.path.exists(fp):
        for r in csv.reader(open(fp, encoding="utf-8")):
            if len(r) < 4 or r[0] < today: continue
            date, time, h, a = r[:4]
            if h not in S or a not in S: continue
            (ah, dh), (aa, da) = S[h], S[a]
            row = dict(date=date, time=time, home=h, away=a, **predict(mu * ah * da * hf, mu * aa * dh * af))
            if h in CF and a in CF:
                cavg = sum(CF.values()) / len(CF)
                conc = lambda t: min(1.3, max(0.75, (cavg / CF[t]) ** 0.4))   # quien genera más córners suele conceder menos
                row["ch"] = round(CF[h] * conc(a) * 1.07, 2); row["ca"] = round(CF[a] * conc(h) * 0.93, 2)
            if h in SH and a in SH:
                # remates del equipo × defensa del rival (goles concedidos relativos) ^0.5 × localía
                cs = lambda t: min(1.35, max(0.7, S[t][1] ** 0.5))
                row["sth"] = round(SH[h][0] * cs(a) * 1.06, 2); row["sta"] = round(SH[a][0] * cs(h) * 0.94, 2)
                row["sh"] = round(SH[h][1] * cs(a) * 1.06, 2); row["sa"] = round(SH[a][1] * cs(h) * 0.94, 2)
            best = max(MK, key=lambda m: sim(m["h"], h) + sim(m["a"], a), default=None)
            if best and sim(best["h"], h) >= 0.5 and sim(best["a"], a) >= 0.5:
                t = best["p1"] + best["px"] + best["p2"]
                mk = dict(p1=round(best["p1"] / t, 4), px=round(best["px"] / t, 4), p2=round(best["p2"] / t, 4), src="Polymarket")
                if best["line"] and best["ov"] and best["un"]:
                    L = best["line"]; po = best["ov"] / (best["ov"] + best["un"])
                    G = row["grid"]; mo = sum(G[i][j] for i in range(8) for j in range(8) if i + j > L) / sum(map(sum, G))
                    mk.update(line=L, pov=round(po, 4), mov=round(mo, 4))
                row["mk"] = mk
            fx.append(row)
    out.append(dict(id=lid, name=name, season=season, mu=round(mu, 2), table=tbl, fixtures=fx))
json.dump(dict(asof=today, leagues=out), open("futbol_out.json", "w"), ensure_ascii=False)
print({o["name"]: len(o["fixtures"]) for o in out})
