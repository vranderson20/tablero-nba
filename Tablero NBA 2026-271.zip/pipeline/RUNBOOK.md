# Actualización diaria del Tablero NBA

Artifact: https://claude.ai/artifact/Ahc2UQtCSrczCm2tbLjgNn
Todo el código y los datos viven como archivos publicados del artifact bajo `pipeline/`.
Zona horaria del usuario: America/Bogota (COT, UTC-5). Horas ET = COT en horario estándar (nov–mar 7);
con horario de verano en EE. UU. (desde el 2.º domingo de marzo) COT = ET − 1 h.

## Actualización de la tarde (solo lesiones y cuotas)

Otra tarea programada corre a las 5:31 p. m. (Colombia) para captar bajas de último momento: pasos 1, 4b y 5, luego
`python3 build.py --asof "<fecha>"` (sin reentrenar), paso 7 (publicar solo nba.html, data/injuries.csv, data/odds.json y
data/history.json) y 7b. Informe de 2 líneas: bajas nuevas importantes y favoritos que cambiaron.

## Pasos

1. **Descargar el pipeline.** `Artifact` action `read`, `url` del artifact, `paths` = todos los archivos de
   `pipeline/` (lista con `scope: "files"`). Guardarlos en un directorio de trabajo, p. ej. `~/nba/pipeline/`,
   respetando las rutas (`data/`, `data/games/`). Instalar si falta: `pip install pandas scipy scikit-learn --break-system-packages`.

2. **Resultados nuevos** (solo WebFetch; curl está bloqueado). Para cada mes de la temporada en curso que tenga
   partidos jugados desde el último registrado en `data/games/2026_27.csv`, pedir a
   `https://www.landofbasketball.com/results/2026_2027_<mes>_scores.htm` (`oct`, `nov`, `dec`, `jan`, `feb`, `mar`, `apr`):
   "Return ONLY CSV rows date(YYYY-MM-DD),away,away_pts,home,home_pts for EVERY completed regular-season NBA game".
   Códigos: ATL BOS BKN CHA CHI CLE DAL DEN DET GSW HOU IND LAC LAL MEM MIA MIL MIN NOP NYK OKC ORL PHI PHX POR SAC SAS TOR UTA WAS.
   Añadir solo filas nuevas (sin duplicar) a `data/games/2026_27.csv` (sin encabezado). Verificar que W-L por
   equipo coincida con https://www.foxsports.com/nba/standings; si no coincide, revisar antes de seguir.

3. **Calendario (temporada completa)**: `data/schedule.csv` contiene TODOS los partidos de temporada regular que faltan
   (encabezado `date,time,away,home`; date = fecha ET, time como `7:30 p. m.` en COT; desde el 14 mar 2027 COT = ET − 1 h).
   Cada día: quitar las filas de partidos ya jugados (los que están en `data/games/2026_27.csv`) y revisar los próximos 8 días con
   `https://www.landofbasketball.com/nba_daily_summary/<AAAAMMDD>.htm` (cambios de hora o partidos nuevos). Los partidos de la Copa NBA
   del 4 al 11 de diciembre se agregan cuando se conozcan los equipos. Para reconstruir el calendario completo:
   `https://www.landofbasketball.com/results/2026_2027_<mes>_scores.htm`, pidiendo medio mes por consulta (la página se corta).
   Comprobación: partidos jugados + pendientes = 82 por equipo.

4. **Plantillas completas (titulares y suplentes)**: para cada uno de los 30 equipos, WebFetch a
   `https://www.basketball-reference.com/teams/<EQ>/2027.html` (códigos Basketball-Reference: ATL BOS BRK CHO CHI CLE DAL
   DEN DET GSW HOU IND LAC LAL MEM MIA MIL MIN NOP NYK OKC ORL PHI PHO POR SAC SAS TOR UTA WAS) con el prompt:
   "From the "Per Game" table (regular season), return ONLY CSV rows for EVERY player listed:
   Player,Pos,Age,G,MP,FG%,3P,3P%,FT%,TRB,AST,STL,BLK,TOV,PTS. Blank percentages as 0. No header, no commentary."
   Guardar cada respuesta en `data/rosters/<EQ>.csv` (sin encabezado; revisar que el nombre del primer jugador esté completo).
   Si un equipo falla, conservar su archivo anterior. Luego `python3 merge_rosters.py` regenera `data/players.csv`.
   Prioriza los equipos que juegan hoy y mañana si hay que recortar.

4a. **Impacto de jugadores (BPM)**, una vez por semana (lunes) o si falta el archivo: WebFetch a
   `https://www.basketball-reference.com/leagues/NBA_2027_advanced.html` en 6 consultas de 5 equipos cada una
   (la página se corta: pedir "Return ONLY CSV rows Player,Team,G,MP_total,BPM for EVERY player whose Team is X, Y or Z. Full names").
   Reescribir `data/bpm.csv` con encabezado `Player,Team,G,MP,BPM`. `build.py` lo usa para el impacto de cada baja
   (promedio de 0.8·(BPM+2)·min/48 y la medida por volumen); a los que no aparezcan los estima con sus estadísticas.

4b. **Lesiones**: WebFetch a https://www.espn.com/nba/injuries con el prompt "Return ONLY CSV rows
   team,player,status,return_date,comment for EVERY player listed (all teams). Status as shown. Keep comment under 80 chars."
   Reescribir `data/injuries.csv` con encabezado `team,player,status,return_date,comment` (team = nombre completo de ESPN,
   return_date como `Nov 22`). La página marca "fuera" si el regreso estimado es posterior al partido y "duda" en otro caso,
   y reparte el volumen de los ausentes entre los disponibles. Si falla, conservar el archivo anterior.

5. **Cuotas** de los partidos de `schedule.csv`: covers.com/sport/basketball/nba/odds, evanalytics.com/nba/odds,
   sportsbookreview.com/betting-odds/nba-basketball/. Actualizar `data/odds.json`, clave `AWAY-HOME` (códigos de
   modelo, p. ej. `ORL-PHX`): `{"open":{"a":ml,"h":ml,"sp":spread_local},"cur":{"a":ml,"h":ml,"sp":..,"tot":..},"src":"..","asof":"YYYY-MM-DD"}`.
   Conservar `open` si ya existía. Quitar claves de partidos ya jugados. Si no hay cuotas, omitir el partido.

5b. **Fútbol** (14 competiciones; ids ESPN: col.1, eng.1, esp.1, ita.1, ger.1, fra.1, por.1, ned.1, eng.2, esp.2, usa.1,
   uefa.champions, uefa.europa, uefa.europa.conf). MLS (usa.1): unir Este y Oeste en una sola tabla ordenada por puntos y renumerar `pos`. Para cada id, WebFetch a `https://www.espn.com/soccer/standings/_/league/<id>` con
   "Return ONLY CSV rows: pos,team,GP,W,D,L,GF,GA,GD,P for the full current table. No commentary." → `data/futbol/<id>.csv`
   (sin encabezado), y a `https://www.espn.com/soccer/schedule/_/league/<id>` con "Return ONLY CSV rows
   date(YYYY-MM-DD),time,home,away for every upcoming (not yet played) match listed. No commentary." → `data/futbol/<id>.fixtures.csv`.
   Las horas de ESPN están en hora del Este (igual a Colombia en horario estándar). Los nombres de equipo deben coincidir
   con los de la tabla. Revisar que no haya partidos duplicados ni ya jugados; si una fuente falla, conservar el archivo anterior.
   El calendario de ESPN solo muestra la semana en curso (en parones FIFA queda vacío): en ese caso tomar los partidos de la próxima
   jornada de las páginas de Polymarket (paso 5e; horas en UTC, restar 5 h) y mapear los nombres a los de la tabla. Quitar partidos con fecha anterior a hoy.

5c. **Córners** (para 5 ligas; BetPlay y copas UEFA no tienen fuente): WebFetch a `https://statz.ai/competitions/<slug>/corners`
   con slug premier-league, la-liga, serie-a, bundesliga, ligue-1 y el prompt "Return ONLY CSV rows team,corners_for_per_match for the
   current season. No commentary." Guardar en `data/futbol/<id>.corners.csv` (eng.1, esp.1, ita.1, ger.1, fra.1) usando los nombres de
   equipo de la tabla ESPN (p. ej. FC Barcelona→Barcelona, Inter→Internacionale, Roma→AS Roma, FC Bayern München→Bayern Munich,
   Paris Saint Germain→Paris Saint-Germain). Si falla, conservar el archivo anterior.

5d. **Remates y remates al arco** (mismas 5 ligas): WebFetch a `https://www.statmuse.com/fc/ask/teams-that-allow-most-shot-on-goal?l=<l>`
   con l = pl, laliga, seriea, bundesliga, ligue1 y el prompt "Return ONLY CSV rows team,games,sot_for_per_game,shots_for_per_game
   for all teams". Guardar `data/futbol/<id>.shots.csv` como `equipo,remates_al_arco_pp,remates_pp` (sin encabezado) con los nombres de
   la tabla ESPN (Inter→Internazionale, Roma→AS Roma, Bayern→Bayern Munich, PSG→Paris Saint-Germain, Rayo→Rayo Vallecano, etc.).
   Comprobar que todos los partidos tengan datos (futbol.py imprime cuántos). Si falla, conservar el archivo anterior.

5e. **Precios de mercado (cuotas reales)**: WebFetch a `https://polymarket.com/sports/<slug>/games` con slug epl, laliga, sea,
   bundesliga, ligue-1, por, ere, elc, mls y el prompt "Return ONLY CSV rows date,home,away,price_home,price_draw,price_away,total_line,over_price,under_price
   (cents) for every listed upcoming game." → `data/futbol/<id>.market.csv` (eng.1, esp.1, ita.1, ger.1, fra.1, por.1, ned.1, eng.2, usa.1; LaLiga 2 no tiene mercado vigente; sin encabezado; los nombres
   se emparejan solos). Para NBA, si un partido no tiene cuotas en covers/evanalytics, usar `https://polymarket.com/sports/nba/games`
   (fechas en UTC) y guardar en `data/odds.json` con `"src":"Polymarket"` convirtiendo el precio a cuota americana justa.

6. **Entrenar y construir**: `cd ~/nba/pipeline && python3 merge_rosters.py && python3 models.py && python3 futbol.py && python3 build.py --asof "<d> <mes> <año>"`.
   `build.py` califica los pronósticos pasados con los resultados, registra los nuevos en `data/history.json`
   (nunca reescribe un pronóstico de un partido ya jugado) y genera `nba.html`.

7. **Publicar** con `Artifact` (publish) al mismo `url`, `file_path` = `nba.html` y `files` con cada archivo de
   `pipeline/` (`pipeline/models.py`, `pipeline/build.py`, `pipeline/template.html`, `pipeline/RUNBOOK.md`,
   `pipeline/merge_rosters.py`, `pipeline/futbol.py`, `pipeline/data/futbol/*.csv` (incluye *.corners.csv), `pipeline/data/*.csv|json`, `pipeline/data/games/*.csv`, `pipeline/data/rosters/*.csv`), `root` = el directorio padre de `pipeline/`.
   Usar `{"from": ..., "contentType": "text/plain"}` para `.py` y `.md`. Nunca usar `force`.

7b. **Archivo para el sitio público**: además, guarda una copia de `nba.html` envuelta en `<!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"></head><body>…</body></html>` como `index.html` en `/mnt/user-data/outputs/` (el usuario lo sube a GitHub Pages: https://vranderson20.github.io/tablero-nba/).

7c. **Subir al sitio público (GitHub Pages)**: `git clone https://github.com/vranderson20/tablero-nba.git` en una carpeta temporal,
   copiar el `index.html` del paso 7b encima del de la raíz, `git -c user.name="Tablero NBA" -c user.email="noreply@anthropic.com" commit -am "Actualización <fecha>"`
   y `git push origin main`. Así el sitio se actualiza solo y basta Ctrl+F5 (GitHub tarda hasta ~10 min en refrescar).
   Si el push responde 403 ("not in this session's authorized repository set"), el repositorio no está agregado a la tarea
   programada: no insistas; deja el index.html en /mnt/user-data/outputs/ y dilo en el informe.

8. **Informe** en 3–4 líneas: partidos calificados ayer (aciertos/fallos), acierto en vivo acumulado,
   pronósticos de hoy (favorito y %), y cualquier dato que no se pudo actualizar.
