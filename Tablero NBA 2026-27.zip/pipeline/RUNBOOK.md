# Actualización diaria del Tablero NBA

Artifact: https://claude.ai/artifact/Ahc2UQtCSrczCm2tbLjgNn
Todo el código y los datos viven como archivos publicados del artifact bajo `pipeline/`.
Zona horaria del usuario: America/Bogota (COT, UTC-5). Horas ET = COT en horario estándar (nov–mar 7);
con horario de verano en EE. UU. (desde el 2.º domingo de marzo) COT = ET − 1 h.

## Pasos

1. **Descargar el pipeline.** `Artifact` action `read`, `url` del artifact, `paths` = todos los archivos de
   `pipeline/` (lista con `scope: "files"`). Guardarlos en un directorio de trabajo, p. ej. `~/nba/pipeline/`,
   respetando las rutas (`data/`, `data/games/`). Instalar si falta: `pip install pandas scipy scikit-learn --break-system-packages`.

2. **Resultados nuevos** (solo WebFetch; curl está bloqueado). Para cada mes de la temporada en curso que tenga
   partidos jugados desde el último registrado en `data/games/2026_27.csv`, pedir a
   `https://www.landofbasketball.com/results/2026_2027_<mes>_scores.htm` (`oct`, `nov`, `dec`, `jan`, `feb`, `mar`, `apr`):
   "Return ONLY CSV rows date(YYYY-MM-DD),away,away_pts,home,home_pts for EVERY completed regular-season NBA game".
   Códigos: ATL BOS BKN CHA CHI CLE DAL DEN DET GSW HOU IND LAC LAL MEM MIA MIL MIN NOP NYK OKC ORL PHI PHX POR SAC SAS TOR UTA WAS.
   Añadir solo filas nuevas (sin duplicar) a `data/games/2026_27.csv` (sin encabezado). Verificar que W-L por
   equipo coincida con https://www.foxsports.com/nba/standings; si no coincide, revisar antes de seguir.

3. **Calendario** de hoy y mañana: https://www.foxsports.com/nba/schedule (sus horas están en UTC; restar 5 h para COT)
   o una búsqueda "NBA schedule <fecha>". Reescribir `data/schedule.csv` con encabezado `date,time,away,home`
   (date = fecha ET del partido, time como `7:30 p. m.` en COT, códigos de arriba). Solo partidos no jugados.

4. **Plantillas completas (titulares y suplentes)**: para cada uno de los 30 equipos, WebFetch a
   `https://www.basketball-reference.com/teams/<EQ>/2027.html` (códigos Basketball-Reference: ATL BOS BRK CHO CHI CLE DAL
   DEN DET GSW HOU IND LAC LAL MEM MIA MIL MIN NOP NYK OKC ORL PHI PHO POR SAC SAS TOR UTA WAS) con el prompt:
   "From the "Per Game" table (regular season), return ONLY CSV rows for EVERY player listed:
   Player,Pos,Age,G,MP,FG%,3P,3P%,FT%,TRB,AST,STL,BLK,TOV,PTS. Blank percentages as 0. No header, no commentary."
   Guardar cada respuesta en `data/rosters/<EQ>.csv` (sin encabezado; revisar que el nombre del primer jugador esté completo).
   Si un equipo falla, conservar su archivo anterior. Luego `python3 merge_rosters.py` regenera `data/players.csv`.
   Prioriza los equipos que juegan hoy y mañana si hay que recortar.

4b. **Lesiones**: WebFetch a https://www.espn.com/nba/injuries con el prompt "Return ONLY CSV rows
   team,player,status,return_date,comment for EVERY player listed (all teams). Status as shown. Keep comment under 80 chars."
   Reescribir `data/injuries.csv` con encabezado `team,player,status,return_date,comment` (team = nombre completo de ESPN,
   return_date como `Nov 22`). La página marca "fuera" si el regreso estimado es posterior al partido y "duda" en otro caso,
   y reparte el volumen de los ausentes entre los disponibles. Si falla, conservar el archivo anterior.

5. **Cuotas** de los partidos de `schedule.csv`: covers.com/sport/basketball/nba/odds, evanalytics.com/nba/odds,
   sportsbookreview.com/betting-odds/nba-basketball/. Actualizar `data/odds.json`, clave `AWAY-HOME` (códigos de
   modelo, p. ej. `ORL-PHX`): `{"open":{"a":ml,"h":ml,"sp":spread_local},"cur":{"a":ml,"h":ml,"sp":..,"tot":..},"src":"..","asof":"YYYY-MM-DD"}`.
   Conservar `open` si ya existía. Quitar claves de partidos ya jugados. Si no hay cuotas, omitir el partido.

6. **Entrenar y construir**: `cd ~/nba/pipeline && python3 merge_rosters.py && python3 models.py && python3 build.py --asof "<d> <mes> <año>"`.
   `build.py` califica los pronósticos pasados con los resultados, registra los nuevos en `data/history.json`
   (nunca reescribe un pronóstico de un partido ya jugado) y genera `nba.html`.

7. **Publicar** con `Artifact` (publish) al mismo `url`, `file_path` = `nba.html` y `files` con cada archivo de
   `pipeline/` (`pipeline/models.py`, `pipeline/build.py`, `pipeline/template.html`, `pipeline/RUNBOOK.md`,
   `pipeline/merge_rosters.py`, `pipeline/data/*.csv|json`, `pipeline/data/games/*.csv`, `pipeline/data/rosters/*.csv`), `root` = el directorio padre de `pipeline/`.
   Usar `{"from": ..., "contentType": "text/plain"}` para `.py` y `.md`. Nunca usar `force`.

8. **Informe** en 3–4 líneas: partidos calificados ayer (aciertos/fallos), acierto en vivo acumulado,
   pronósticos de hoy (favorito y %), y cualquier dato que no se pudo actualizar.
