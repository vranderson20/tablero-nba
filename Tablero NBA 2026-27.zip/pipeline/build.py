"""Genera nba.html a partir de template.html + datos, y actualiza data/history.json.
Uso: python3 models.py && python3 build.py [--asof "5 nov 2026"]"""
import json, glob, sys, datetime as dt
import pandas as pd

NAMES = {"ATL":("Hawks","E"),"BOS":("Celtics","E"),"BKN":("Nets","E"),"CHA":("Hornets","E"),"CHI":("Bulls","E"),"CLE":("Cavaliers","E"),
 "DET":("Pistons","E"),"IND":("Pacers","E"),"MIA":("Heat","E"),"MIL":("Bucks","E"),"NYK":("Knicks","E"),"ORL":("Magic","E"),"PHI":("76ers","E"),
 "TOR":("Raptors","E"),"WAS":("Wizards","E"),"DAL":("Mavericks","W"),"DEN":("Nuggets","W"),"GSW":("Warriors","W"),"HOU":("Rockets","W"),
 "LAC":("Clippers","W"),"LAL":("Lakers","W"),"MEM":("Grizzlies","W"),"MIN":("Timberwolves","W"),"NOP":("Pelicans","W"),"OKC":("Thunder","W"),
 "PHX":("Suns","W"),"POR":("Trail Blazers","W"),"SAC":("Kings","W"),"SAS":("Spurs","W"),"UTA":("Jazz","W")}
TO_PAGE = {"PHX":"PHO","CHA":"CHO","BKN":"BRK"}
pg = lambda t: TO_PAGE.get(t, t)
DIAS = ["lun","mar","mié","jue","vie","sáb","dom"]; MESES = ["ene","feb","mar","abr","may","jun","jul","ago","sep","oct","nov","dic"]
def dlabel(d): d = pd.Timestamp(d); return f"{DIAS[d.weekday()]} {d.day} {MESES[d.month-1]}"

M = json.load(open("model_out.json"))
G = pd.concat([pd.read_csv(f, header=None, names=["date","a","ap","h","hp"]) for f in sorted(glob.glob("data/games/*.csv"))]).drop_duplicates()
G["date"] = pd.to_datetime(G.date)
G["season"] = G.date.dt.year.where(G.date.dt.month < 7, G.date.dt.year + 1)
CUR = int(G.season.max()); C = G[G.season == CUR]
SCH = pd.read_csv("data/schedule.csv")
ODDS = json.load(open("data/odds.json")) if glob.glob("data/odds.json") else {}
try: HIST = json.load(open("data/history.json"))
except FileNotFoundError: HIST = []
asof = sys.argv[sys.argv.index("--asof") + 1] if "--asof" in sys.argv else dlabel(dt.date.today()).split(" ", 1)[1] + f" {dt.date.today().year}"

# ---- clasificación desde los resultados ----
TEAMS = {}
for t, (n, c) in NAMES.items():
    hm, aw = C[C.h == t], C[C.a == t]
    w = int((hm.hp > hm.ap).sum() + (aw.ap > aw.hp).sum()); g = len(hm) + len(aw)
    pf = (hm.hp.sum() + aw.ap.sum()) / g if g else 0; pa = (hm.ap.sum() + aw.hp.sum()) / g if g else 0
    TEAMS[pg(t)] = [n, c, w, g - w, round(float(pf), 1), round(float(pa), 1)]

# ---- mercado ----
impl = lambda ml: -ml / (-ml + 100) if ml < 0 else 100 / (ml + 100)
def fair_home(k):
    o = ODDS.get(k, {}).get("cur", {})
    if o.get("a") is None or o.get("h") is None: return None
    ia, ih = impl(o["a"]), impl(o["h"]); return ih / (ia + ih)

# ---- histórico: calificar resultados y registrar pronósticos ----
res = {f"{r.date.date()}-{r.a}-{r.h}": (int(r.ap), int(r.hp)) for r in G.itertuples()}
byid = {e["id"]: e for e in HIST}
for p in M["preds"]:
    gid = f'{p["date"]}-{p["a"]}-{p["h"]}'
    if gid in res: continue                      # ya se jugó: no se reescribe el pronóstico
    pm = fair_home(f'{p["a"]}-{p["h"]}'); pe = p["probs"]["ensamble"]
    byid[gid] = dict(id=gid, date=p["date"], a=p["a"], h=p["h"], src="en vivo", pe=round(pe, 4),
                     pm=round(pm, 4) if pm is not None else None, p=round(0.6 * pm + 0.4 * pe if pm is not None else pe, 4),
                     php=round((p["total"] + p["margin"]) / 2, 1), pap=round((p["total"] - p["margin"]) / 2, 1),
                     logged=str(dt.date.today()), ap=None, hp=None)
for b in M.get("backtest", []):
    gid = f'{b["date"]}-{b["a"]}-{b["h"]}'
    if gid not in byid or byid[gid]["src"] == "validación":
        byid[gid] = dict(id=gid, date=b["date"], a=b["a"], h=b["h"], src="validación", pe=b["p"], pm=None, p=b["p"],
                         php=None, pap=None, logged=None, ap=b["ap"], hp=b["hp"])
for e in byid.values():
    if e["id"] in res: e["ap"], e["hp"] = res[e["id"]]
HIST = sorted(byid.values(), key=lambda e: (e["date"], e["id"]))
json.dump(HIST, open("data/history.json", "w"), ensure_ascii=False, indent=0)

# ---- lesiones (ESPN) ----
import unicodedata, csv
FULL = {"Atlanta Hawks":"ATL","Boston Celtics":"BOS","Brooklyn Nets":"BRK","Charlotte Hornets":"CHO","Chicago Bulls":"CHI","Cleveland Cavaliers":"CLE",
 "Dallas Mavericks":"DAL","Denver Nuggets":"DEN","Detroit Pistons":"DET","Golden State Warriors":"GSW","Houston Rockets":"HOU","Indiana Pacers":"IND",
 "LA Clippers":"LAC","Los Angeles Clippers":"LAC","Los Angeles Lakers":"LAL","Memphis Grizzlies":"MEM","Miami Heat":"MIA","Milwaukee Bucks":"MIL",
 "Minnesota Timberwolves":"MIN","New Orleans Pelicans":"NOP","New York Knicks":"NYK","Oklahoma City Thunder":"OKC","Orlando Magic":"ORL",
 "Philadelphia 76ers":"PHI","Phoenix Suns":"PHO","Portland Trail Blazers":"POR","Sacramento Kings":"SAC","San Antonio Spurs":"SAS",
 "Toronto Raptors":"TOR","Utah Jazz":"UTA","Washington Wizards":"WAS"}
norm = lambda n: unicodedata.normalize("NFD", n).encode("ascii", "ignore").decode().lower().replace(".", "").replace("'", "").strip()
INJ = {}
if glob.glob("data/injuries.csv"):
    for r in csv.DictReader(open("data/injuries.csv", encoding="utf-8")):
        try:
            rd = pd.Timestamp(f'{r["return_date"]} {CUR - 1}')
            if rd.month < 7: rd = rd.replace(year=CUR)
            rd = str(rd.date())
        except Exception: rd = None
        INJ[norm(r["player"])] = dict(tm=FULL.get(r["team"], ""), s="out" if r["status"].lower().startswith("out") else "q", r=rd, c=r["comment"][:90])

# ---- página ----
P = pd.read_csv("data/players.csv")
csv = "\n".join(",".join(str(v) for v in r) for r in P.itertuples(index=False))
games = [[dlabel(r.date), r.time, pg(r.away), pg(r.home), str(r.date)] for r in SCH.itertuples()]
model = dict(metrics=M["metrics"], n_test=M["n_test"], n_all=M["n_all"], imp_rf=M["imp_rf"], imp_gb=M["imp_gb"], coef_lin=M["coef_lin"],
             elo=M["elo"], ewma=M["ewma"], series=M["series"], resid_sd=M["resid_sd"], tot_sd=M["tot_sd"],
             preds={p["a"] + "-" + p["h"]: {**{k: p[k] for k in ["probs","margin","total","lam_h","lam_a","elo_h","elo_a"]},
                    "rest_h": p["feats"]["h_rest"], "rest_a": p["feats"]["a_rest"]} for p in M["preds"]})
market = {k: {"open": v.get("open"), "cur": v["cur"]} for k, v in ODDS.items() if k in model["preds"]}
J = lambda o: json.dumps(o, ensure_ascii=False, separators=(",", ":"))
h = open("template.html").read()
for k, v in {"__TEAMS__": J(TEAMS), "__CSV__": J(csv), "__GAMES__": J(games), "__MODEL__": J(model), "__HISTORY__": J(HIST),
             "__MARKET__": J(market), "__INJ__": J(INJ), "__ASOF__": asof, "__NGAMES__": f'{M["n_games"]:,}'.replace(",", "."),
             "__NTEST__": str(M["n_test"]), "__NPLAYERS__": str(len(P)), "__SEASON__": f"{CUR-1}-{str(CUR)[2:]}"}.items():
    h = h.replace(k, v)
assert "__" not in h.replace("__proto__", ""), "placeholder sin reemplazar"
open("nba.html", "w").write(h)
live = [e for e in HIST if e["src"] == "en vivo"]
print(f"OK · {len(games)} partidos próximos · histórico {len(HIST)} ({len(live)} en vivo, {sum(e['hp'] is not None for e in live)} calificados)")
