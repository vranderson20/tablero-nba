"""Entrena Elo, Poisson, regresión lineal/logística, Random Forest, Gradient Boosting,
red neuronal y suavizado exponencial (serie de tiempo) sobre resultados NBA 2025-26 y 2026-27.
Salida: model_out.json con métricas de validación y predicciones de los próximos partidos."""
import glob, json, math
import numpy as np, pandas as pd
from scipy.stats import norm, skellam
from sklearn.linear_model import LinearRegression, LogisticRegression, PoissonRegressor
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier, RandomForestRegressor, GradientBoostingRegressor
from sklearn.neural_network import MLPClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
from sklearn.metrics import accuracy_score, log_loss, brier_score_loss, mean_absolute_error

G = pd.concat([pd.read_csv(f, header=None, names=["date","a","ap","h","hp"]) for f in sorted(glob.glob("data/games/*.csv"))])
G["date"] = pd.to_datetime(G.date); G = G.drop_duplicates().sort_values("date", kind="stable").reset_index(drop=True)
G["season"] = np.where(G.date.dt.month >= 7, G.date.dt.year + 1, G.date.dt.year)
CUR = int(G.season.max())

SCH = pd.read_csv("data/schedule.csv")  # date,time,away,home (códigos tipo PHX/CHA/BKN)
UPCOMING = [(r.date, r.away, r.home) for r in SCH.itertuples()]

K, HCA_ELO, CARRY = 20, 70, 0.75
EW_ALPHA = 0.15  # suavizado exponencial del margen
SHR = 8

teams = sorted(set(G.a) | set(G.h))
def fresh():
    return {t: dict(elo=1500.0, ew=0.0, ewo=0.0, ewd=0.0, g=0, pf=0, pa=0, last=None, hist=[]) for t in teams}
S = fresh(); cur_season = None; rows = []
LG_PTS = 115.0

def feats(a, h, date):
    A, H = S[a], S[h]
    def shr(T, x): return x * T["g"] / (T["g"] + SHR) if T["g"] else 0.0
    def net(T): return shr(T, (T["pf"] - T["pa"]) / T["g"]) if T["g"] else 0.0
    def off(T): return shr(T, T["pf"] / T["g"] - LG_PTS) if T["g"] else 0.0
    def dfn(T): return shr(T, T["pa"] / T["g"] - LG_PTS) if T["g"] else 0.0
    def rest(T):
        if T["last"] is None: return 3
        return min(3, (date - T["last"]).days - 1)
    return dict(elo_diff=(H["elo"] + HCA_ELO - A["elo"]) / 100, net_diff=net(H) - net(A),
                ew_diff=H["ew"] - A["ew"], h_off=off(H), h_def=dfn(H), a_off=off(A), a_def=dfn(A),
                ew_h_off=H["ewo"], ew_h_def=H["ewd"], ew_a_off=A["ewo"], ew_a_def=A["ewd"],
                h_rest=rest(H), a_rest=rest(A), h_b2b=int(rest(H) == 0), a_b2b=int(rest(A) == 0))
FEATS = list(feats(teams[0], teams[1], pd.Timestamp("2025-10-21")).keys())

def elo_prob(diff100): return 1 / (1 + 10 ** (-diff100 * 100 / 400))

for r in G.itertuples():
    if r.season != cur_season:
        if cur_season is not None:
            for t in teams:  # regresión a la media entre temporadas
                S[t]["elo"] = 1500 + CARRY * (S[t]["elo"] - 1500)
                S[t]["ew"] *= 0.5; S[t]["ewo"] *= .5; S[t]["ewd"] *= .5
                S[t].update(g=0, pf=0, pa=0)
        cur_season = r.season
    f = feats(r.a, r.h, r.date); f.update(date=r.date, season=r.season, a=r.a, h=r.h, ap=r.ap, hp=r.hp,
                                         margin=r.hp - r.ap, total=r.hp + r.ap, hwin=int(r.hp > r.ap),
                                         elo_p=elo_prob(f["elo_diff"]))
    rows.append(f)
    # actualizar Elo (con multiplicador por margen, estilo FiveThirtyEight)
    A, H = S[r.a], S[r.h]
    p = elo_prob((H["elo"] + HCA_ELO - A["elo"]) / 100); m = r.hp - r.ap
    mult = ((abs(m) + 3) ** 0.8) / (7.5 + 0.006 * abs((H["elo"] + HCA_ELO) - A["elo"]))
    d = K * mult * ((1 if m > 0 else 0) - p); H["elo"] += d; A["elo"] -= d
    for T, pf, pa in ((H, r.hp, r.ap), (A, r.ap, r.hp)):
        T["ew"] = (1 - EW_ALPHA) * T["ew"] + EW_ALPHA * (pf - pa)
        T["ewo"] = (1 - EW_ALPHA) * T["ewo"] + EW_ALPHA * (pf - LG_PTS)
        T["ewd"] = (1 - EW_ALPHA) * T["ewd"] + EW_ALPHA * (pa - LG_PTS)
        T["g"] += 1; T["pf"] += pf; T["pa"] += pa; T["last"] = r.date
        T["hist"].append(dict(d=str(r.date.date()), m=int(pf - pa), s=int(r.season)))

D = pd.DataFrame(rows)
D = D.iloc[150:].reset_index(drop=True)   # período de calentamiento de Elo
FOLDS = [str(d.date()) for d in pd.date_range("2026-01-01", D.date.max() + pd.offsets.MonthBegin(1), freq="MS")]
def build():
    return {
        "logistica": make_pipeline(StandardScaler(), LogisticRegression(C=0.05, max_iter=2000)),
        "random_forest": RandomForestClassifier(n_estimators=400, max_depth=5, min_samples_leaf=25, random_state=7, n_jobs=-1),
        "gradient_boosting": GradientBoostingClassifier(n_estimators=200, max_depth=2, learning_rate=0.03, subsample=0.8, random_state=7),
        "red_neuronal": make_pipeline(StandardScaler(), MLPClassifier(hidden_layer_sizes=(8,), alpha=1.0, max_iter=4000, random_state=7)),
    }
def regs():
    return {"lineal": make_pipeline(StandardScaler(), LinearRegression()),
            "poisson_h": make_pipeline(StandardScaler(), PoissonRegressor(alpha=0.5, max_iter=2000)),
            "poisson_a": make_pipeline(StandardScaler(), PoissonRegressor(alpha=0.5, max_iter=2000)),
            "total": make_pipeline(StandardScaler(), LinearRegression())}
# validación walk-forward: entrenar con todo lo anterior, predecir el mes siguiente
P_test = {k: [] for k in ["elo","lineal","poisson","logistica","random_forest","gradient_boosting","red_neuronal","serie_tiempo"]}
M_test = {"lineal": [], "poisson": []}; Y_test = []; MARG = []; IDX = []
for i in range(len(FOLDS) - 1):
    tr = D[D.date < FOLDS[i]]; te = D[(D.date >= FOLDS[i]) & (D.date < FOLDS[i + 1])]
    if not len(te): continue
    X, Xt, y = tr[FEATS].values, te[FEATS].values, tr.hwin.values
    R = regs(); R["lineal"].fit(X, tr.margin); mp = R["lineal"].predict(Xt)
    sd = float(np.std(tr.margin - R["lineal"].predict(X)))
    R["poisson_h"].fit(X, tr.hp); R["poisson_a"].fit(X, tr.ap)
    lh, la = R["poisson_h"].predict(Xt), R["poisson_a"].predict(Xt)
    P_test["elo"] += list(te.elo_p); P_test["lineal"] += list(norm.cdf(mp / sd))
    P_test["poisson"] += list(1 - skellam.cdf(0, lh, la) + 0.5 * skellam.pmf(0, lh, la))
    P_test["serie_tiempo"] += list(norm.cdf((te.ew_diff.values + 2.5) / 12.5))
    M_test["lineal"] += list(mp); M_test["poisson"] += list(lh - la)
    for n, mdl in build().items():
        mdl.fit(X, y); P_test[n] += list(mdl.predict_proba(Xt)[:, 1])
    Y_test += list(te.hwin); MARG += list(te.margin); IDX += list(te.index)
yt = np.array(Y_test); MARG = np.array(MARG)
metrics = {}
def score(name, p, margin_pred=None):
    p = np.clip(np.array(p), 0.02, 0.98)
    m = dict(acierto=round(accuracy_score(yt, p > .5) * 100, 1), log_loss=round(log_loss(yt, p), 4), brier=round(brier_score_loss(yt, p), 4))
    if margin_pred is not None: m["mae_margen"] = round(mean_absolute_error(MARG, margin_pred), 2)
    metrics[name] = m
for k, v in P_test.items(): score(k, v, M_test.get(k))
score("ensamble", np.mean([np.array(v) for v in P_test.values()], axis=0))
score("base_localia", np.full(len(yt), D[D.date < FOLDS[0]].hwin.mean()))
train = D[D.date < FOLDS[0]]; test = D[D.date >= FOLDS[0]]
ENS = np.mean([np.array(v) for v in P_test.values()], axis=0)
backtest = [dict(date=str(D.loc[ix, "date"].date()), a=D.loc[ix, "a"], h=D.loc[ix, "h"], ap=int(D.loc[ix, "ap"]), hp=int(D.loc[ix, "hp"]),
                 p=round(float(pe), 4)) for ix, pe in zip(IDX, ENS) if D.loc[ix, "season"] == CUR]

# ---------- reentrenar con todo y predecir ----------
Xa, ya = D[FEATS].values, D.hwin.values
R = regs(); R["lineal"].fit(Xa, D.margin); R["poisson_h"].fit(Xa, D.hp); R["poisson_a"].fit(Xa, D.ap); R["total"].fit(Xa, D.total)
resid_sd = float(np.std(D.margin - R["lineal"].predict(Xa))); tot_sd = float(np.std(D.total - R["total"].predict(Xa)))
C = build()
for mdl in C.values(): mdl.fit(Xa, ya)
imp_rf = dict(zip(FEATS, C["random_forest"].feature_importances_.round(3).tolist()))
imp_gb = dict(zip(FEATS, C["gradient_boosting"].feature_importances_.round(3).tolist()))
coef_lin = dict(zip(FEATS, (R["lineal"][-1].coef_).round(3).tolist()))

preds = []
for date, a, h in UPCOMING:
    dt = pd.Timestamp(date)
    f = feats(a, h, dt); x = np.array([[f[k] for k in FEATS]])
    lam_h, lam_a = float(R["poisson_h"].predict(x)[0]), float(R["poisson_a"].predict(x)[0])
    mar = float(R["lineal"].predict(x)[0]); tot = float(R["total"].predict(x)[0])
    p = {"elo": elo_prob(f["elo_diff"]), "lineal": float(norm.cdf(mar / resid_sd)),
         "poisson": float(1 - skellam.cdf(0, lam_h, lam_a) + 0.5 * skellam.pmf(0, lam_h, lam_a)),
         "serie_tiempo": float(norm.cdf((f["ew_diff"] + 2.5) / 12.5))}
    for n, mdl in C.items(): p[n] = float(mdl.predict_proba(x)[0, 1])
    p["ensamble"] = float(np.mean(list(p.values())))
    preds.append(dict(date=date, a=a, h=h, probs={k: round(v, 4) for k, v in p.items()},
                      margin=round(mar, 2), total=round(tot, 1), lam_h=round(lam_h, 1), lam_a=round(lam_a, 1),
                      feats={k: round(float(v), 3) for k, v in f.items()},
                      elo_h=round(S[h]["elo"]), elo_a=round(S[a]["elo"])))
    # el partido del 5 influye en el descanso del 6
    pass

out = dict(metrics=metrics, n_train=int(len(train)), n_test=int(len(test)), n_all=int(len(D)),
           resid_sd=round(resid_sd, 2), tot_sd=round(tot_sd, 2), imp_rf=imp_rf, imp_gb=imp_gb, coef_lin=coef_lin,
           elo={t: round(S[t]["elo"]) for t in teams}, ewma={t: round(S[t]["ew"], 2) for t in teams},
           series={t: [x["m"] for x in S[t]["hist"] if x["s"] == CUR] for t in teams},
           preds=preds, backtest=backtest, last_game=str(G.date.max().date()), n_games=int(len(G)), hca_home_rate=round(float(D.hwin.mean()), 3))
json.dump(out, open("model_out.json", "w"), ensure_ascii=False, indent=1)
print(json.dumps(metrics, indent=1)); print(len(train), len(test))
for p in preds: print(p["a"], "@", p["h"], p["probs"]["ensamble"], p["margin"], p["total"])
print("RF", sorted(imp_rf.items(), key=lambda x: -x[1])[:5])
