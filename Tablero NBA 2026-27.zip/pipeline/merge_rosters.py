"""Une data/rosters/<EQUIPO>.csv (sin encabezado; equipo = nombre del archivo, códigos Basketball-Reference)
en data/players.csv. Mantiene jugadores con al menos 1 partido y 1 minuto por partido."""
import glob, os, csv
rows = []
for f in sorted(glob.glob("data/rosters/*.csv")):
    tm = os.path.basename(f)[:-4]
    for r in csv.reader(open(f, encoding="utf-8")):
        if len(r) != 15 or r[0] == "Player": continue
        name, pos, age, *nums = r
        try: vals = [float(x or 0) for x in nums]
        except ValueError: continue
        if vals[0] < 1: continue
        rows.append([name, tm, pos, age] + nums)
with open("data/players.csv", "w", newline="", encoding="utf-8") as o:
    w = csv.writer(o); w.writerow("Player,Team,Pos,Age,G,MP,FG%,3P,3P%,FT%,TRB,AST,STL,BLK,TOV,PTS".split(","))
    w.writerows(rows)
print(len(rows), "jugadores en", len(glob.glob("data/rosters/*.csv")), "equipos")
